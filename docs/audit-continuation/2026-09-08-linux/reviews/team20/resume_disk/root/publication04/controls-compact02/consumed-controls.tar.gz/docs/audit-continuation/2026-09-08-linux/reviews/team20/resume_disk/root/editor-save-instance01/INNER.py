#!/usr/bin/python3
"""Fresh one-method editor PID1 source; SOURCE ONLY, unbound and unexecuted.

Derived generic descriptor/namespace/command/stop contracts from reviewed GUI07.
No GUI, native test, Room, recovery, old runtime or old runner is imported/executed.
Root alone admits new raw-P23+test-overlay copy, original coordinator and cleanup.
Exactly one selected real VM/fake-repository method; no CLI --tests or suite rerun.
"""
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import select
import selectors
import signal
import stat
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

W = Path('/root/projects/PassVault/passvault-linux')
B = W / 'docs/audit-continuation/2026-09-08-linux'
R = Path('/root/projects/PassVault/audit-runtime-linux-editor-save-ack01')
E = B / 'runs/linux-editor-save-ack01'
CHECKOUT = R / 'checkout'
SELF, INIT, OVERLAY = Path('/root/projects/PassVault/passvault-linux/docs/audit-continuation/2026-09-08-linux/reviews/team20/resume_disk/root/editor-save-instance01/INNER.py'), Path('/root/projects/PassVault/passvault-linux/docs/audit-continuation/2026-09-08-linux/reviews/team20/resume_disk/root/editor-save-instance01/INIT.gradle'), Path('/root/projects/PassVault/passvault-linux/docs/audit-continuation/2026-09-08-linux/reviews/team20/resume_disk/root/editor-save-instance01/CredentialCustomFieldDraftTest.kt')
SOURCE = B / 'reviews/checkpoint23/source-prepare01/SOURCE.json'
JAVA = Path('/usr/lib/jvm/java-17-openjdk-amd64')
PROSPECTIVE_ADMISSION_BOUND = True
INPUTS = (SELF, INIT, SOURCE, OVERLAY, JAVA / 'bin/java', JAVA / 'release')
COMMIT, TREE, MEMBERS = '59bee33096f538b9444f00236448d7fc0ea740b2', '76a7dd46c0c1d69bae554c4eb02106da2ac1f6c6', 5121
SOURCE_BINDING = {'representation': 'P23_RAW_GIT_BLOBS_PLUS_ONE_EDITOR_TEST_OVERLAY', 'base_commit': '59bee33096f538b9444f00236448d7fc0ea740b2', 'base_tree': '76a7dd46c0c1d69bae554c4eb02106da2ac1f6c6', 'source_manifest_sha256': '1984fc3221b38fbd4e1c894b0a5b2cc13df8828dc7b5415aa50b0e887e47fccc', 'members': 5121, 'base_raw_bytes': 153458946, 'observed_checkout_bytes': 153460893, 'framed_transport_bytes': 153725453, 'effective_bytes': 153460963, 'base_content_identity_sha256': '19211d126337ddf19a37a6b89522642d62dcc247c199a6420cdc1e4b28abd91c', 'effective_content_identity_sha256': '67290541b1cfa3a170617122a2b6a381e2f1eaa52ab103ea93d9eca1464dd726'}
SOURCE_OVERLAY = {'path': 'feature/credential/src/commonTest/kotlin/com/passvault/feature/credential/presentation/CredentialCustomFieldDraftTest.kt', 'git_mode': '100644', 'before': {'bytes': 15170, 'sha256': 'b45ded2bb7e092e73975f7b7d4e77c8e649ae72f1b7f07db9445b47559c176c2', 'git_blob': 'c790bd877a79bb6a96577a614e28ac28f3b79c06'}, 'after': {'bytes': 17187, 'sha256': '1db3bbb9edd917351093634dc92ab1b2a1d1a6a18f6ef7e675d7f54ad782334b', 'git_blob': 'a146557630de2deb7f7e8e4db934570c5975d301'}, 'scope': 'Exactly one existing amended Save acknowledgement method and import; no new methods, dependency or production edit'}
RESOURCE_POLICY = 'EDITOR_SAVE_ACK01_12GiB_ENTRY_3GiB_RUNNING_3GiB_PRIVATE_256MiB_DISK_512MiB_RAM_V1'
DISPOSAL_POLICY_ID = 'EDITOR_SAVE_ACK1_ORIGINAL_SETTLED_TEST_WORK_CANCELLED_COPY_ONLY_V1'
RUN_ID = 'linux-editor-save-ack01'
FROZEN = {SOURCE: '1984fc3221b38fbd4e1c894b0a5b2cc13df8828dc7b5415aa50b0e887e47fccc', INIT: '1ab0e58856856fd37a9a1f883678f4a3311c569045758be7456b3d7c555fc2dd', OVERLAY: '1db3bbb9edd917351093634dc92ab1b2a1d1a6a18f6ef7e675d7f54ad782334b'}
MIB, GIB = 1024 ** 2, 1024 ** 3
SELECTIONS = ({'module': 'feature/credential', 'task': ':feature:credential:desktopTest', 'worker': 'credential', 'class': 'com.passvault.feature.credential.presentation.CredentialCustomFieldDraftTest', 'suite': 'CredentialCustomFieldDraftTest[desktop]', 'methods': ('failed page Save keeps adopted values dirty and retry persists them',), 'fixture': 'feature/credential/src/commonTest/kotlin/com/passvault/feature/credential/presentation/CredentialCustomFieldDraftTest.kt', 'sha256': '1db3bbb9edd917351093634dc92ab1b2a1d1a6a18f6ef7e675d7f54ad782334b'},)
PRODUCTION_SOURCE = {
    'feature/credential/src/commonMain/kotlin/com/passvault/feature/credential/presentation/CredentialViewModel.kt':
        'b9a9c5e6a9e9a5eee86a13a639fa32826dbfdfbd09fa81a032935a37f58f0611',
    'core/testing/src/commonMain/kotlin/com/passvault/core/testing/fakes/FakeCredentialRepository.kt':
        'e23527840b0c9ffa1baa99bc70550c28115ea357fe213d5f436b568dfa76686a',
}
WORKERS = ('credential',)
CHILDREN = ('home', 'tmp', 'jna', 'sqlite', 'xdg-cache', 'xdg-config', 'xdg-data', 'xdg-state')
PRIVATE = ('checkout', 'home', 'tmp', 'jna', 'sqlite', 'gradle-home', 'konan', 'android-user',
           'xdg-cache', 'xdg-config', 'xdg-data', 'xdg-state', 'workers')
ORIGINAL_DIRS = (R, E, E / 'logs', E / 'xml') + tuple(R / p for p in PRIVATE) + tuple(
    p for w in WORKERS for p in (R / 'workers' / w, *(R / 'workers' / w / c for c in CHILDREN)))
FLAGS = ['--no-daemon', '--max-workers=1', '--console=plain', '--no-parallel', '--no-configure-on-demand',
         '--no-configuration-cache', '--no-build-cache', '--dependency-verification=strict', '--stacktrace',
         '-Pkotlin.compiler.execution.strategy=in-process', '-Pandroid.builder.sdkDownload=false',
         '-Dorg.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8', '-Dorg.gradle.java.installations.auto-download=false',
         '-Dorg.gradle.java.installations.auto-detect=false', '-Dorg.gradle.java.installations.paths=' + str(JAVA)]
CASE_COMMAND = [str(CHECKOUT / 'gradlew'), '--init-script', str(INIT),
                '-Ppassvault.audit.mode=editor-save-ack', ':feature:credential:desktopTest'] + FLAGS
STOP = [str(CHECKOUT / 'gradlew'), '--stop'] + FLAGS
ENV = {'PATH': str(JAVA / 'bin') + ':/usr/bin:/bin', 'JAVA_HOME': str(JAVA), 'LANG': 'C.UTF-8',
       'LC_ALL': 'C.UTF-8', 'TZ': 'UTC', 'HOME': str(R / 'home'), 'GRADLE_USER_HOME': str(R / 'gradle-home'),
       'KONAN_DATA_DIR': str(R / 'konan'), 'ANDROID_USER_HOME': str(R / 'android-user'),
       'ANDROID_HOME': '/opt/android-sdk', 'ANDROID_SDK_ROOT': '/opt/android-sdk',
       'TMPDIR': str(R / 'tmp'), 'TMP': str(R / 'tmp'), 'TEMP': str(R / 'tmp'), 'SQLITE_TMPDIR': str(R / 'sqlite'),
       **{'XDG_' + k.upper() + '_HOME': str(R / ('xdg-' + k)) for k in ('cache', 'config', 'data', 'state')},
       'JAVA_TOOL_OPTIONS': '-Xmx512m -XX:-UsePerfData -Dfile.encoding=UTF-8 -Duser.home=' + str(R / 'home')
       + ' -Djava.io.tmpdir=' + str(R / 'tmp') + ' -Djna.tmpdir=' + str(R / 'jna')
       + ' -Dorg.sqlite.tmpdir=' + str(R / 'sqlite')}
CANCEL = set()

def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def pidfd_terminal(pidfd):
    # poll(0) avoids select's FD_SETSIZE limit without adopting/closing any fd.
    require(type(pidfd) is int and pidfd >= 0, 'original pidfd required for terminal observation')
    observer = select.poll()
    observer.register(pidfd, select.POLLIN)
    events = observer.poll(0)
    require(len(events) <= 1, 'original pidfd poll result count')
    if not events:
        return False
    descriptor, mask = events[0]
    require(descriptor == pidfd and not mask & (select.POLLERR | select.POLLNVAL),
            'original pidfd poll error/invalid descriptor')
    # IN is exit readiness; HUP is also read-select readiness, including after
    # Linux pidfd reaping. Neither replaces the original wait/namespace checks.
    require(mask & (select.POLLIN | select.POLLHUP)
            and not mask & ~(select.POLLIN | select.POLLHUP), 'unexpected original pidfd poll events')
    return True


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode() + b'\n'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(st, directory=False):
    result = {k: getattr(st, 'st_' + k) for k in ('dev', 'ino', 'uid', 'mode', 'nlink')}
    if not directory:
        result.update(bytes=st.st_size, mtime_ns=st.st_mtime_ns, ctime_ns=st.st_ctime_ns)
    return result


def directory_identity(value):
    return {k: value[k] for k in ('dev', 'ino', 'uid', 'mode')}


def note(errors, error):
    value = str(error)[:1024]
    if value not in errors:
        if len(errors) < 127:
            errors.append(value)
        elif len(errors) == 127:
            errors.append('Additional errors omitted at the 128-entry evidence bound')


def proc_read(path, cap):
    with open(path, 'rb') as stream:
        data = stream.read(cap + 1)
    require(len(data) <= cap, 'proc metadata bound')
    return data.decode('ascii')


class Files:
    def __init__(self):
        self.dirs, self.expected, self.evidence = {}, {}, {}
        self.pending = set()
        self.write_close_failed = False

    def directory(self, path):
        path = Path(path)
        require(path.is_absolute() and '..' not in path.parts, 'absolute canonical directory')
        parent = None if path == Path('/') else self.directory(path.parent)
        if path not in self.dirs:
            fd = os.open(path.name if parent is not None else '/', os.O_RDONLY | os.O_DIRECTORY
                         | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent)
            self.dirs[path] = (fd, directory_identity(pin(os.fstat(fd), True)))
        fd, original = self.dirs[path]
        require(directory_identity(pin(os.fstat(fd), True)) == original, 'original directory descriptor drift')
        if parent is not None:
            require(directory_identity(pin(os.stat(path.name, dir_fd=parent, follow_symlinks=False), True))
                    == original, 'original directory path drift')
        if str(path) in self.expected:
            require(original == directory_identity(self.expected[str(path)]), 'outer original directory mismatch')
        return fd

    def read(self, path, cap):
        path = Path(path)
        parent = self.directory(path.parent)
        original = pin(os.stat(path.name, dir_fd=parent, follow_symlinks=False))
        require(stat.S_ISREG(original['mode']) and original['uid'] == os.getuid() and original['nlink'] == 1
                and not original['mode'] & 0o022 and original['bytes'] <= cap, 'owned single-link bounded file')
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=parent)
        with os.fdopen(fd, 'rb') as stream:
            require(pin(os.fstat(stream.fileno())) == original, 'file open drift')
            data = stream.read(cap + 1)
            require(len(data) == original['bytes'] and pin(os.fstat(stream.fileno())) == original
                    == pin(os.stat(path.name, dir_fd=parent, follow_symlinks=False)), 'stable bounded file read')
        return data, {'sha256': sha(data), 'pin': original}

    def new(self, path):
        parent = self.directory(path.parent)
        fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                     0o600, dir_fd=parent)
        self.pending.add(path)
        try:
            os.fsync(parent)
        except Exception:
            os.close(fd)
            raise
        return fd

    def finish(self, path, fd, data_hash, size):
        os.fsync(fd)
        value = pin(os.fstat(fd))
        parent = self.directory(path.parent)
        os.fsync(parent)
        require(value == pin(os.stat(path.name, dir_fd=parent, follow_symlinks=False))
                and value['bytes'] == size and value['nlink'] == 1 and value['uid'] == os.getuid()
                and value['mode'] == stat.S_IFREG | 0o600, 'completed original evidence image')
        self.evidence[path] = {'sha256': data_hash, 'pin': value}
        self.pending.remove(path)
        return self.evidence[path]

    def write(self, path, data):
        fd = self.new(path)
        try:
            view = memoryview(data)
            while view:
                count = os.write(fd, view)
                require(count > 0, 'evidence short write')
                view = view[count:]
            return self.finish(path, fd, sha(data), len(data))
        finally:
            try:
                os.close(fd)
            except OSError:
                self.write_close_failed = True
                raise

    def verify(self):
        require(not self.pending and not self.write_close_failed, 'unfinished/uncertain original evidence files')
        for path in tuple(self.dirs):
            self.directory(path)
        # One case, two command logs, source/phase/XML receipts; no crops or application archives.
        require(len(self.evidence) <= 48 and sum(v['pin']['bytes'] for v in self.evidence.values()) <= 32 * MIB,
                'compact evidence aggregate bound')
        for path, expected in self.evidence.items():
            require(self.read(path, 4 * MIB)[1] == expected, 'preserved evidence drift')

    def close(self):
        failed = None
        for fd, _ in reversed(tuple(self.dirs.values())):
            try:
                os.close(fd)
            except OSError as error:
                failed = error
        if failed is not None:
            raise failed


def namespace_preflight(parent):
    require(os.getpid() == 1 and os.getppid() == 0, 'fresh PID1/PPID0 required')
    current = {k: os.readlink('/proc/self/ns/' + k) for k in ('pid', 'mnt')}
    require(all(re.fullmatch(k + r':\[[0-9]+\]', parent[k]) and current[k] != parent[k] for k in current),
            'distinct original parent namespaces')
    initial_net = os.readlink('/proc/self/ns/net')
    require(re.fullmatch(r'net:\[[0-9]+\]', parent['net']) and initial_net == parent['net'],
            'initial online stage must retain the original parent network namespace')
    status = dict(line.split(':', 1) for line in proc_read('/proc/self/status', 32768).splitlines())
    require(all(status[k].strip() == v for k, v in (('Pid', '1'), ('Tgid', '1'), ('PPid', '0'), ('NSpid', '1'))),
            'fresh proc self PID mapping')
    lines = proc_read('/proc/self/mountinfo', 131072).splitlines()
    require(0 < len(lines) <= 2048, 'mount metadata count')
    dev = os.stat('/proc').st_dev
    visible, device = 0, '%s:%s' % (os.major(dev), os.minor(dev))
    for line in lines:
        left, separator, right = line.partition(' - ')
        prefix, suffix = left.split(), right.split(' ')
        # Preserve an empty SOURCE slot only. Namespace01 raw failed row is absent;
        # this corrects the independently witnessed valid-format counterexample.
        require(separator and len(prefix) >= 6 and len(suffix) == 3 and suffix[0] and suffix[2],
                'mountinfo positional fields; empty superoptions forbidden')
        require(not any(v.startswith(('shared:', 'master:', 'propagate_from:')) for v in prefix[6:]),
                'propagating mount forbidden')
        if prefix[4] == '/proc' and prefix[2] == device:
            require(suffix[0] == 'proc' and {'nosuid', 'nodev', 'noexec'} <= set(prefix[5].split(',')),
                    'visible proc type/security flags')
            visible += 1
    require(visible, 'visible private proc absent')
    return {'parent': parent, 'self': current, 'initial_net': initial_net, 'nonpropagating_mounts': True, 'mount_rows': len(lines)}


class EditorSaveAck01:
    def __init__(self, files, parent):
        self.f, self.parent, self.started = files, parent, time.monotonic()
        self.errors, self.phases, self.inputs = [], [], {}
        self.source = self.initial = None
        self.before = self.after = self.namespace_ok = self.evidence_ok = False
        self.last_resource = self.last_inventory = 0.0
        self.settlement_remaining, self.inventories = 120.0, []
        self.work_deadline_ns = None
        self.xml_attempted = self.xml_preserved = self.xml_ok = False
        self.preserved_xml_suites, self.xml_result_image = 0, None
        self.case_attempted = self.case_ok = self.case_cancelled_work = False
        self.cleanup_blocked = self.evidence_retained = self.source_after_skipped_for_cancel = False
        self.disposal_policy = None

    def note(self, error):
        note(self.errors, error)

    def cancelled(self):
        try:
            os.stat('CANCEL', dir_fd=self.f.directory(E), follow_symlinks=False)
            CANCEL.add('outer-file')
        except FileNotFoundError:
            pass
        return bool(CANCEL)

    def intake(self):
        data, image = self.f.read(E / 'OUTER-INTENT.json', 4 * MIB)
        value = json.loads(data)
        require(value['format'] == 'passvault-linux-editor-save-ack01-outer-v1' and value['run_id'] == RUN_ID
                and value['commit'] == COMMIT and value['tree'] == TREE and value['source_members'] == MEMBERS
                and value['source_representation'] == SOURCE_BINDING['representation']
                and value['source_binding'] == SOURCE_BINDING and value['source_overlay'] == SOURCE_OVERLAY
                and value['resource_policy'] == RESOURCE_POLICY and value['parent_namespaces'] == self.parent,
                'fixed fresh editor-save-ack01 outer intake; not independent execution admission')
        require(isinstance(value['disposal_policy'], dict)
                and value['disposal_policy']['id'] == DISPOSAL_POLICY_ID
                and value['disposal_policy']['runtime'] == str(R)
                and value['disposal_policy']['retained_evidence'] == str(E)
                and value['disposal_policy']['root_selected'] is True, 'fresh original disposal scope absent')
        self.disposal_policy = value['disposal_policy']
        deadline, now = value['work_deadline_monotonic_ns'], time.monotonic_ns()
        require(type(deadline) is int and 0 < deadline - now <= 5250 * 1_000_000_000,
                'original outer monotonic work deadline missing/expired/reset')
        self.work_deadline_ns = deadline
        self.f.expected = value['directories']
        for path in ORIGINAL_DIRS:
            require(str(path) in self.f.expected and self.f.expected[str(path)]['uid'] == os.getuid()
                    and self.f.expected[str(path)]['mode'] == stat.S_IFDIR | 0o700, 'original private allocation')
            self.f.directory(path)
        self.inputs[E / 'OUTER-INTENT.json'] = image
        overlay_data, overlay_image = self.f.read(E / 'SOURCE-OVERLAY.json', 65536)
        overlay_record = json.loads(overlay_data)
        require(overlay_image == value['overlay_image'] and overlay_record['source_binding'] == SOURCE_BINDING
                and overlay_record['overlay'] == SOURCE_OVERLAY
                and overlay_record['base_raw_source'] == value['base_raw_source']
                and overlay_record['effective_source'] == value['effective_source']
                and value['base_raw_source']['content_identity_sha256'] == SOURCE_BINDING['base_content_identity_sha256']
                and value['effective_source']['content_identity_sha256'] == SOURCE_BINDING['effective_content_identity_sha256'],
                'explicit base/overlay/effective source provenance missing')
        self.inputs[E / 'SOURCE-OVERLAY.json'] = overlay_image
        captured = {}
        for path in INPUTS:
            captured[path], actual = self.f.read(path, 32 * MIB)
            require(actual == value['images'][str(path)] and actual['sha256'] == FROZEN.get(path, actual['sha256']),
                    'exact immutable input/tool image')
            self.inputs[path] = actual
        require(b'JAVA_VERSION="17.' in captured[JAVA / 'release']
                and b'OS_ARCH="x86_64"' in captured[JAVA / 'release'], 'JDK17 x86_64')
        self.source = json.loads(captured[SOURCE])
        require(self.source['format'] == 'passvault-linux-checkout-source-v1'
                and self.source['commit'] == COMMIT and self.source['tree'] == TREE
                and len(self.source['files']) == MEMBERS
                and len({r['path'] for r in self.source['files']}) == MEMBERS
                and len(self.source['checkout_eol_qualifications']) == 2, 'full source/two EOL qualifications')
        overlay_rows = [r for r in self.source['files'] if r['path'] == SOURCE_OVERLAY['path']]
        require(len(overlay_rows) == 1 and overlay_rows[0]['git_mode'] == SOURCE_OVERLAY['git_mode']
                and overlay_rows[0]['git_blob'] == SOURCE_OVERLAY['before']['git_blob']
                and overlay_rows[0]['raw_size'] == SOURCE_OVERLAY['before']['bytes']
                and overlay_rows[0]['raw_sha256'] == SOURCE_OVERLAY['before']['sha256'],
                'exact sole overlay beforeimage absent from unmodified P23 manifest')
        require(captured[OVERLAY] and sha(captured[OVERLAY]) == SOURCE_OVERLAY['after']['sha256']
                and len(captured[OVERLAY]) == SOURCE_OVERLAY['after']['bytes'], 'frozen test overlay input')
        selected_source = {**{v['fixture']: v['sha256'] for v in SELECTIONS}, **PRODUCTION_SOURCE}
        for path, digest in selected_source.items():
            selected = [r for r in self.source['files'] if r['path'] == path]
            require(len(selected) == 1, 'single original selected source row')
            expected_digest = (SOURCE_OVERLAY['after']['sha256'] if path == SOURCE_OVERLAY['path']
                               else selected[0]['raw_sha256'])
            require(expected_digest == digest, 'exact effective fixture/VM/fake source selection')
        require(not os.path.lexists(CHECKOUT / '.git'), 'disposable raw source only; no borrowed repository')

    def check_inputs(self, stopping=False):
        for path, image in self.inputs.items():
            if not stopping or path in (JAVA / 'bin/java', JAVA / 'release'):
                require(self.f.read(path, 32 * MIB)[1] == image, 'admitted input drift')

    def source_check(self, label, wrapper_only=False):
        started, count, size = time.monotonic(), 0, 0
        identities = []
        for row in self.source['files']:
            if wrapper_only and row['path'] not in ('gradlew', 'gradle/wrapper/gradle-wrapper.jar',
                                                   'gradle/wrapper/gradle-wrapper.properties'):
                continue
            require(time.monotonic() - started <= 180 and (wrapper_only or not self.cancelled()),
                    'source scan deadline/cancellation')
            relative = Path(row['path'])
            require(not relative.is_absolute() and '..' not in relative.parts, 'source relative path')
            data, image = self.f.read(CHECKOUT / relative, 32 * MIB)
            blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            digest = sha(data)
            expected_blob = row['git_blob']
            if row['path'] == SOURCE_OVERLAY['path']:
                expected_blob = SOURCE_OVERLAY['after']['git_blob']
                require(len(data) == SOURCE_OVERLAY['after']['bytes']
                        and digest == SOURCE_OVERLAY['after']['sha256'], 'sole approved overlay afterimage drift')
            require(blob == expected_blob and row['git_mode'] in ('100644', '100755')
                    and bool(image['pin']['mode'] & 0o111) == (row['git_mode'] == '100755'),
                    'INTEGRATION06 explicit base/effective blob/mode drift')
            identities.append([row['path'], row['git_mode'], blob, len(data), digest])
            count, size = count + 1, size + len(data)
        require(count == (3 if wrapper_only else MEMBERS), 'source member count')
        if not wrapper_only:
            require(not os.path.lexists(CHECKOUT / '.git'), 'raw source only: Git directory appeared')
            identity = sha(canonical(sorted(identities, key=lambda row: row[0])))
            require(identity == SOURCE_BINDING['effective_content_identity_sha256']
                    and size == SOURCE_BINDING['effective_bytes'], 'complete effective-source identity drift')
            self.f.write(E / ('SOURCE-' + label + '.json'), canonical({'commit': COMMIT, 'tree': TREE,
                'representation': SOURCE_BINDING['representation'], 'source_binding': SOURCE_BINDING,
                'source_overlay': SOURCE_OVERLAY, 'content_identity_sha256': identity,
                'members': count, 'bytes': size,
                'checkout_eol_qualifications': self.source['checkout_eol_qualifications']}))

    def resources(self, launch=False):
        now = time.monotonic()
        if not launch and now - self.last_resource < 5:
            return
        self.last_resource = now
        memory = dict(line.split(':', 1) for line in proc_read('/proc/meminfo', 65536).splitlines())
        available, total = (int(memory[k].split()[0]) * 1024 for k in ('MemAvailable', 'MemTotal'))
        disks = [os.fstatvfs(self.f.directory(p)) for p in (R, E)]
        require(min(s.f_bavail * s.f_frsize for s in disks) >= 3 * GIB
                and available / total >= (0.25 if launch else 0.20), 'disk/RAM floor')
        if launch or now - self.last_inventory >= 30:
            self.last_inventory = now
            require(len(self.inventories) < 256, 'resource point-sample count bound')
            sample = {'directories': 0, 'examined_entries': 0, 'files': 0, 'logical_bytes': 0,
                      'vanished_entries': 0, 'vanished_scan_directories': 0, 'traversal_finished': False}
            self.inventories.append(sample)

            def vanished(path, directory=False):
                path = Path(path)
                require(path.is_relative_to(R) and path not in ORIGINAL_DIRS,
                        'root/critical original runtime path disappeared')
                require(time.monotonic() - now <= 30, 'runtime inventory deadline')
                sample['vanished_scan_directories' if directory else 'vanished_entries'] += 1

            def walk_error(error):
                if not isinstance(error, FileNotFoundError):
                    raise error
                vanished(error.filename, True)

            # ENOENT below noncritical fresh R paths is retained sample incompleteness,
            # NOT host provenance, absence of data, or permission to delete anything.
            for parent, children, names in os.walk(R, followlinks=False, onerror=walk_error):
                sample['directories'] += 1
                require(time.monotonic() - now <= 30 and sample['directories'] <= 30000,
                        'runtime inventory directory/time cap')
                for name in children + names:
                    sample['examined_entries'] += 1  # Including vanished entries: churn cannot evade this cap.
                    require(sample['examined_entries'] <= 230000 and time.monotonic() - now <= 30,
                            'runtime examined-entry/time cap')
                    path = Path(parent) / name
                    try:
                        value = path.lstat()
                    except FileNotFoundError:
                        vanished(path)
                        continue
                    require(value.st_uid == os.getuid() and (stat.S_ISREG(value.st_mode) or stat.S_ISDIR(value.st_mode)),
                            'runtime inventory ownership/type uncertainty')
                    if stat.S_ISREG(value.st_mode):
                        sample['files'] += 1
                        sample['logical_bytes'] += value.st_size
                    require(sample['files'] <= 200000 and sample['logical_bytes'] <= 3 * GIB, 'runtime inventory cap')
            sample['traversal_finished'] = True

    def settle(self):
        require(self.namespace_ok, 'no membership scan without positive private namespace preflight')
        started, empty = time.monotonic(), 0
        try:
            while time.monotonic() - started < self.settlement_remaining:
                try:
                    while os.waitpid(-1, os.WNOHANG)[0]:
                        pass
                except ChildProcessError:
                    pass
                members = {int(n) for n in os.listdir('/proc') if n.isdigit()}
                require(1 in members and len(members) <= 65536, 'namespace process view/count')
                empty = empty + 1 if members == {1} else 0
                if empty >= 2:
                    return True
                self.resources()
                self.cancelled()
                time.sleep(0.2)
            return False
        finally:
            self.settlement_remaining = max(0, self.settlement_remaining - (time.monotonic() - started))

    def command(self, label, argv, env, seconds, phase, stopping=False, gradle=True, input_data=None):
        record = {'label': label, 'argv': argv, 'started': False, 'exit': None, 'complete': False,
                  'errors': [], 'cancelled_work_only': False}
        phase['commands'].append(record)
        require(input_data is None or (isinstance(input_data, bytes) and len(input_data) <= 1024), 'bounded command stdin')
        fd = pidfd = child = None
        digest, count, abort, killed = hashlib.sha256(), 0, None, False
        path = E / 'logs' / (label + '.log')
        try:
            fd = self.f.new(path)
            if stopping:
                require(not phase['stop_attempted'], 'stop already attempted; no retry')
                phase['stop_attempted'] = True
            else:
                require(not self.cancelled(), 'cancel before build intent')
                if gradle:
                    phase['stop_required'] = True
            self.f.write(E / (label + '-INTENT.json'), canonical({'argv': argv, 'cwd': str(CHECKOUT),
                'environment_sha256': sha(canonical(env)), 'seconds': seconds, 'stop_required': phase['stop_required'],
                'stdin_sha256': None if input_data is None else sha(input_data)}))
            require(stopping or not self.cancelled(), 'cancel before build launch; original stop retained')
            child = subprocess.Popen(argv, cwd=CHECKOUT, env=env, stdin=subprocess.DEVNULL if input_data is None else subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, close_fds=True)
            record['started'], record['namespace_pid'] = True, child.pid
            pidfd = os.pidfd_open(child.pid, 0)  # Direct child remains unreaped; never signal a reused numeric PID.
            if input_data is not None:
                require(child.stdin.write(input_data) == len(input_data), 'bounded stdin short write')
                child.stdin.close()
            os.set_blocking(child.stdout.fileno(), False)
            started, eof, exited = time.monotonic(), False, None
            with selectors.DefaultSelector() as selector:
                selector.register(child.stdout, selectors.EVENT_READ)
                while True:
                    for key, _ in selector.select(0.2):
                        data = os.read(key.fileobj.fileno(), 65536)
                        if not data:
                            selector.unregister(key.fileobj)
                            eof = True
                        else:
                            kept = data[:max(0, 4 * MIB - count)]
                            require(os.write(fd, kept) == len(kept), 'log short write')
                            digest.update(kept)
                            count += len(kept)
                            if len(kept) != len(data):
                                note(record['errors'], 'log cap')
                    try:
                        self.resources()
                    except Exception as error:
                        note(record['errors'], error)
                    cancelled = self.cancelled()
                    now = time.monotonic()  # Resource/syscall time is not subtracted from cooperative deadlines.
                    # The NEW 600s stop envelope includes its 20s TERM/KILL tail.
                    expired = now - started >= seconds - (20 if stopping else 0)
                    expired = expired or (not stopping and now - self.started >= 6000)
                    if expired or record['errors'] or (cancelled and not stopping):
                        if abort is None:
                            record['cancelled_work_only'] = bool(cancelled and not stopping
                                                                 and not expired and not record['errors'])
                            abort = now
                            note(record['errors'], 'command timeout/cancel/resource/output failure')
                            self.signal_child(pidfd, signal.SIGTERM)
                        elif now - abort >= 10 and not killed:
                            self.signal_child(pidfd, signal.SIGKILL)
                            killed = True
                        elif now - abort >= 20:
                            break
                    record['exit'] = child.poll()
                    if record['exit'] is not None:
                        exited = now if exited is None else exited
                        if eof:
                            record['complete'] = True
                            break
                        if now - exited >= 10:
                            note(record['errors'], 'pipe remains held after direct exit')
                            break
        except Exception as error:
            note(record['errors'], type(error).__name__ + ': ' + str(error))
        finally:
            try:
                if pidfd is not None and not record['complete'] and not killed:
                    self.signal_child(pidfd, signal.SIGKILL)
                if child is not None:
                    record['exit'] = child.poll()
                    child.stdout.close()
            except Exception as error:
                note(record['errors'], 'direct-child finalization: ' + str(error))
            if fd is not None:
                try:
                    record['log'] = self.f.finish(path, fd, digest.hexdigest(), count)
                except Exception as error:
                    note(record['errors'], 'log preservation: ' + str(error))
            for descriptor in (pidfd, fd):
                if descriptor is not None:
                    try:
                        os.close(descriptor)
                    except OSError as error:
                        note(record['errors'], 'original descriptor close: ' + str(error))
        record['disposal_command_complete'] = bool(record['started'] and record['complete']
            and record['exit'] is not None and 'log' in record
            and (not record['errors'] or (record['cancelled_work_only']
                and record['errors'] == ['command timeout/cancel/resource/output failure'])))
        return record['complete'] and record['exit'] == 0 and not record['errors']

    @staticmethod
    def signal_child(pidfd, sig):
        try:
            signal.pidfd_send_signal(pidfd, sig)
        except ProcessLookupError:
            pass  # Original direct child is already terminal; no numeric-PID fallback or retry.

    def state(self, mode):
        phase = {'phase': mode, 'commands': [], 'stop_required': False, 'stop_attempted': False,
                 'stop_ok': False, 'build_ok': False, 'settled': False}
        self.phases.append(phase)
        return phase

    def stop(self, phase, env):
        if phase['stop_required']:
            try:
                self.check_inputs(stopping=True)
                self.source_check('STOP', True)
                phase['stop_ok'] = self.command(phase['phase'] + '-stop', STOP, env, 600, phase, True)
            except Exception as error:
                self.note(phase['phase'] + ': original wrapper stop incomplete/no retry: ' + str(error))

    def run_case(self):
        # Fresh one-method composition; execution still requires root instance admission.
        # Entry main already proved fresh private PID1/proc/mounts/source BEFORE.
        # Uses unchanged command/stop/settle/Files contracts; no GUI/native helpers.
        phase = self.state('case')
        try:
            self.check_inputs()
            require(self.settle() and os.readlink('/proc/self/ns/net') == self.parent['net'],
                    'original online namespace and owned-worker settlement required')
            root = R / 'workers' / 'credential'
            require(set(os.listdir(self.f.directory(root))) == set(CHILDREN)
                    and all(not os.listdir(self.f.directory(root / name)) for name in CHILDREN),
                    'unused isolated synthetic credential worker storage')
            self.resources(True)
            require(self.work_deadline_ns - time.monotonic_ns() >= 3000 * 1_000_000_000,
                    'insufficient original case/stop/source/settlement budget; no reset')
            self.case_attempted = True  # Intent, not an executed XML case.
            phase['build_ok'] = self.command('case', CASE_COMMAND, ENV, 1800, phase)
        finally:
            self.stop(phase, ENV)  # Original wrapper/environment; once even after work failure/cancel.
            phase['settled'] = self.settle()
            if phase['settled']:
                self.preserve_xml()  # Missing/partial/failed XML is retained failure, not assumed success.
            phase['record_image'] = self.f.write(E / 'PHASE-case.json', canonical(phase))
        self.case_ok = phase['build_ok'] and phase['stop_ok'] and phase['settled'] and self.xml_ok
        self.case_cancelled_work = bool(self.cancelled() and phase['stop_ok'] and phase['settled']
            and len(phase['commands']) == 2
            and [c['label'] for c in phase['commands']] == ['case', 'case-stop']
            and phase['commands'][0]['cancelled_work_only']
            and all(c.get('disposal_command_complete') is True for c in phase['commands']))
        # Candidate only: both finalizers below independently validate the NEW Test cancellation
        # scope, original command/stop/namespace and retained XML before original-copy disposal.
        # Cancellation before launch/after normal command completion is deliberately not promoted.

    def preserve_xml(self):
        require(not self.xml_attempted, 'XML preservation already attempted; no retry')
        self.xml_attempted = True
        observed, captures, mapping = set(), [], True
        expected = {CHECKOUT / v['module'] / 'build/test-results/desktopTest' / ('TEST-' + v['class'] + '.xml'): v
                    for v in SELECTIONS}
        listings = []
        # One feature/credential module, one exact amended existing method; no GUI case.
        for module in dict.fromkeys(v['module'] for v in SELECTIONS):
            directory = CHECKOUT / module / 'build/test-results/desktopTest'
            task = next(v['task'] for v in SELECTIONS if v['module'] == module)
            try:
                names = [n for n in os.listdir(self.f.directory(directory)) if n.startswith('TEST-') and n.endswith('.xml')]
            except FileNotFoundError:
                names = []
            listings.append((module, task, directory, names))
        require(sum(len(row[3]) for row in listings) <= 2, 'single-module XML aggregate file count bound')
        for module, task, directory, names in listings:
            for name in sorted(names):
                path = directory / name
                selected = expected.get(path)
                observed.add(path)
                data, original = self.f.read(path, 2 * MIB)
                # Fixed module prefix prevents collisions while preserving unexpected
                # readable XML as failures, never as successful selected test cases.
                saved = self.f.write(E / 'xml' / (module.replace('/', '--') + '--' + name), data)
                captures.append({'source': str(path), 'selected_task': task,
                                 'original': original, 'saved': saved})
                try:
                    require(selected is not None and data and b'<!DOCTYPE' not in data and b'<!ENTITY' not in data,
                            'unexpected/empty/declaring XML')
                    suite = ET.fromstring(data)
                    cases = suite.findall('testcase')
                    require(suite.tag == 'testsuite' and suite.get('name') == selected['suite']
                            and collections.Counter((t.get('classname'), t.get('name')) for t in cases)
                            == collections.Counter((selected['class'], method + '[desktop]')
                                                   for method in selected['methods']), 'exact single editor method mapping')
                    count = len(selected['methods'])
                    require(suite.get('tests') == str(count) and len(cases) == count
                            and all(suite.get(k) == '0' for k in ('failures', 'errors', 'skipped'))
                            and all(not list(t.findall('failure') + t.findall('error') + t.findall('skipped'))
                                    for t in cases), 'failure/error/skip is not an editor PASS')
                except (RuntimeError, ET.ParseError) as error:
                    mapping = False
                    self.note('editor XML: ' + str(error))
        self.preserved_xml_suites = len(captures)
        self.xml_preserved, self.xml_ok = True, mapping and observed == set(expected)
        self.xml_result_image = self.f.write(E / 'XML-RESULT.json', canonical({
            'captures': captures, 'preserved': True, 'mapping_ok': self.xml_ok,
            'declared_cases': 1, 'declared_xml_suites': 1, 'declared_test_tasks': 1,
            'preserved_xml_suites': self.preserved_xml_suites,
            'qualification': 'One real VM/fake-repository method; missing/partial/extra XML is not PASS. '
                             'Not Room, rendered input, native security, lock-race, hardware or a family closure.',
        }))
        if not self.xml_ok:
            self.note('missing/extra/failed/skipped editor XML; no success from task counts or compilation')


def main():
    require(PROSPECTIVE_ADMISSION_BOUND, 'SOURCE ONLY: fresh editor instance is unbound')
    require(sys.platform == 'linux' and sys.argv[0] == str(SELF) and len(sys.argv) == 4
            and sys.flags.isolated and sys.dont_write_bytecode and sys.flags.no_site
            and os.getuid() == os.geteuid() == 0, 'fixed isolated absolute root entry')
    require(all(isinstance(v, str) and re.fullmatch(r'[0-9a-f]{40}', v) for v in (COMMIT, TREE))
            and type(MEMBERS) is int and MEMBERS == 5121
            and all(re.fullmatch(r'[0-9a-f]{64}', value) for value in FROZEN.values()),
            'unbound source identity')
    os.umask(0o077)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, lambda number, _frame: CANCEL.add(number))
    files = Files()
    batch = EditorSaveAck01(files, dict(zip(('pid', 'mnt', 'net'), sys.argv[1:])))
    settled, code = False, 70
    try:
        batch.intake()
        batch.initial = namespace_preflight(batch.parent)
        batch.namespace_ok = True
        files.write(E / 'INNER-PREFLIGHT.json', canonical(batch.initial))
        require(batch.settle(), 'unexpected initial owned namespace member')
        batch.source_check('BEFORE')
        batch.before = True
        batch.run_case()
    except Exception as error:
        batch.cleanup_blocked = True  # No generic exception-to-disposal conversion.
        batch.note(type(error).__name__ + ': ' + str(error))
    finally:
        try:
            settled = batch.settle() if batch.namespace_ok else False
            if settled:
                if batch.case_attempted and not batch.xml_attempted:
                    batch.preserve_xml()
                if batch.before:
                    if batch.cancelled():
                        batch.source_after_skipped_for_cancel = True
                    else:
                        batch.source_check('AFTER')
                        batch.after = True
            batch.check_inputs()
            files.verify()
            batch.evidence_retained = True  # Byte conservation, never semantic acceptance.
            if batch.cancelled():
                batch.note('validation cancelled; original case/stop/XML evidence retained')
            else:
                batch.evidence_ok = True
        except Exception as error:
            batch.cleanup_blocked = True
            batch.note('final source/namespace/evidence uncertainty: ' + str(error))
        phase_shape = (len(batch.phases) == 1 and batch.phases[0]['phase'] == 'case'
            and batch.phases[0]['stop_required'] is True
            and [c['label'] for c in batch.phases[0]['commands']] == ['case', 'case-stop'])
        stops = all(not p['stop_required'] or (p['stop_attempted'] and p['stop_ok']) for p in batch.phases)
        complete = phase_shape and all('record_image' in p and all(c['started'] and c['complete']
            and 'log' in c and not c['errors'] for c in p['commands']) for p in batch.phases)
        safe = (batch.namespace_ok and batch.before and batch.after and stops and settled
            and batch.evidence_ok and complete and batch.xml_preserved and not CANCEL
            and not batch.cleanup_blocked)
        cancelled_disposal = (batch.case_cancelled_work and phase_shape and not batch.cleanup_blocked
            and batch.cancelled() and batch.namespace_ok and batch.before
            and batch.source_after_skipped_for_cancel and not batch.after
            and stops and settled and batch.evidence_retained and batch.xml_preserved
            and batch.phases[0]['settled'] is True and 'record_image' in batch.phases[0]
            and batch.phases[0]['commands'][0]['cancelled_work_only'] is True
            and all(c.get('disposal_command_complete') is True for c in batch.phases[0]['commands']))
        disposal_safe = safe or cancelled_disposal
        passed = safe and batch.case_attempted and batch.case_ok and batch.xml_ok and not batch.errors
        result = {'format': 'passvault-linux-editor-save-ack01-inner-v1', 'run_id': RUN_ID,
            'commit': COMMIT, 'tree': TREE, 'parent_namespaces': batch.parent,
            'source_binding': SOURCE_BINDING, 'source_overlay': SOURCE_OVERLAY, 'resource_policy': RESOURCE_POLICY,
            'source_before': batch.before, 'source_after': batch.after,
            'source_after_status': ('CHECKED' if batch.after else 'NOT_CHECKED_WORK_CANCELLED'
                                    if batch.source_after_skipped_for_cancel else 'NOT_CHECKED_UNCERTAIN'),
            'all_required_stops_ok': stops, 'namespace_empty_before_exit': settled,
            'cleanup_safe': disposal_safe, 'validation_safe': safe, 'evidence_retained': batch.evidence_retained,
            'disposal_policy': batch.disposal_policy,
            'disposal_scope': ('NORMAL_VALIDATION_SAFE' if safe else
                              'SINGLE_TEST_WORK_CANCELLED' if cancelled_disposal else 'HOLD'),
            'case_attempted': batch.case_attempted, 'case_cancelled_work': batch.case_cancelled_work,
            'xml_preserved': batch.xml_preserved, 'xml_mapping_ok': batch.xml_ok,
            'xml_result_image': batch.xml_result_image, 'preserved_xml_suites': batch.preserved_xml_suites,
            'declared_cases': 1, 'declared_xml_suites': 1, 'declared_test_tasks': 1,
            'validation_mapping_ok': passed, 'executed_case_requires_exact_xml': True,
            'outer_work_deadline_monotonic_ns': batch.work_deadline_ns,
            'errors': batch.errors, 'phases': batch.phases,
            'source_references': {'manifest_sha256': FROZEN[SOURCE], 'init_sha256': FROZEN[INIT],
                'overlay_sha256': FROZEN[OVERLAY], 'selection': SELECTIONS, 'VM_and_fake': PRODUCTION_SOURCE},
            'resource_point_samples_not_ownership_or_cleanup_proof': batch.inventories,
            'independent_semantic_acceptance': False,
            'qualification': 'One amended existing real VM/fake-repository Save acknowledgement/retry method; '
                'not Room, rendered input, Add acknowledgement, lock/disposal race, native security, '
                'Android/Apple/Windows/hardware, recovery, PVD or a family closure. Same13methods; one selected. '
                'Cancelled work retains XML observations separately; source-after unknown is not acceptance.'}
        try:
            files.write(E / 'INNER-RESULT.json', canonical(result))
            files.verify()
            code = (0 if passed else 1) if disposal_safe else 70
        except Exception:
            code = 70
        finally:
            try:
                files.close()
            except Exception:
                code = 70
    os._exit(code)


if __name__ == '__main__':
    main()
